/** Automatically generated file. DO NOT MODIFY */
package com.yljt.cascadingmenu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}