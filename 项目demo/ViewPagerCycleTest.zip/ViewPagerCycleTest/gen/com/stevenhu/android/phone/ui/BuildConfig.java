/** Automatically generated file. DO NOT MODIFY */
package com.stevenhu.android.phone.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}